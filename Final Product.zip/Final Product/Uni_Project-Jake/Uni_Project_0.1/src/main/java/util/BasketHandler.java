/**
 * 
 */
package util;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import model.Product;

/**
 * @author owens
 *
 */
public class BasketHandler {
	
	public static boolean addToBasket(int pid, int qty, int uid){
		
		try {
			CallableStatement cs = DbConnector.getConnection().prepareCall("{call insertItemIntoBasket(?,?,?,?)}");
			cs.setInt(1, uid);
			cs.setInt(2, pid);
			cs.setInt(3,  qty);
			cs.registerOutParameter(4, Types.INTEGER);
			cs.execute();
			
			return true;
		} catch(SQLException sqle){
			System.out.println(sqle);
		}
		return false;
		
	}
	
	public static List<Product> getItemsFromBasket(int uid) throws SQLException {

		CallableStatement cs = DbConnector.getConnection().prepareCall("{CALL getBasketItems(?)}");
		
		cs.setInt(1, uid);
		ResultSet rs = cs.executeQuery();
		
		return ProductHandler.resultSetToProducts(rs, true);
		
	}

}
