package util;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

public class UserHandler {

	public static Integer signIn(String user, String password) {
		
		try {
			CallableStatement cs = DbConnector.getConnection().prepareCall("{call loginCheck(?,?)}");
			cs.setString(1, user);
			cs.setString(2, password);
			ResultSet rs = cs.executeQuery();
			
			if (rs.next()) {
				return rs.getInt(1);
			}
			
		} catch (SQLException sqle) {
			System.out.println(sqle);
		}
		
		return -1;
	}
	
	public static boolean createAccount(String user, String password, boolean isAdmin) {
		try {
			Connection conn = DbConnector.getConnection();
			CallableStatement cs;
			
			//if (signIn(user, password) == -1) {
				//return false;
			//}
			
			if (isAdmin) {
				cs = conn.prepareCall("{call newAdmin(?,?)}");
			}
			else {
				cs = conn.prepareCall("call newUser(?,?)");
			}
			cs.setString(1, user);
			cs.setString(2, password);
			cs.execute();
			
			return true;
		} catch (SQLException sqle) {
			System.out.println(sqle);
		}
		
		return false;
	}
	
}
