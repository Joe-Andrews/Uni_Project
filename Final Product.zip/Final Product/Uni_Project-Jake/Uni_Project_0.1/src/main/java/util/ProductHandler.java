package util;

import java.sql.ResultSet;
import java.sql.CallableStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.*;

public class ProductHandler {
	
	public static List<Product> getProductsBySearch(String search) throws SQLException {

		CallableStatement cs = DbConnector.getConnection().prepareCall("{CALL searchNameProduct(?)}");
		cs.setString(1, search);
		ResultSet rs = cs.executeQuery();
		
		return resultSetToProducts(rs);

	}
	
	public static List<Product> getTea() throws SQLException {
		
		CallableStatement cs = DbConnector.getConnection().prepareCall("{CALL showByType(?)}");
		cs.setString(1, "tea");
		ResultSet rs = cs.executeQuery();
		
		return resultSetToProducts(rs);
		
	}
	
	public static List<Product> getCoffee() throws SQLException {
		
		CallableStatement cs = DbConnector.getConnection().prepareCall("{CALL showByType(?)}");
		cs.setString(1, "coffee");
		ResultSet rs = cs.executeQuery();
		
		return resultSetToProducts(rs);
	}
	
	public static List<Product> getProducts() throws SQLException {

		ResultSet rs = DbConnector.runSqlCallable("{call readProducts()}");
		return resultSetToProducts(rs);
	}
	
	public static List<Product> resultSetToProducts(ResultSet rs) throws SQLException {
		return resultSetToProducts(rs, false);
	}
	
	public static List<Product> resultSetToProducts(ResultSet rs, boolean isBasket) throws SQLException{
		List<Product> products = new ArrayList<>();
		
		Product p;
		
		while(rs.next()){
			
			if (rs.getString("Type").equals("tea")) {
				if (rs.getInt("Caffeine") == 0) {
					
					p = new Product(
							rs.getInt("Id"),
							rs.getString("Name"),
							rs.getString("Supplier"),
							rs.getInt("PriceInPence"),
							rs.getString("BrewColour"),
							rs.getString("MedicinalUse")
					);
				}
				else {
					p = new Product(
							rs.getInt("Id"),
							rs.getString("Name"),
							rs.getString("Supplier"),
							rs.getInt("PriceInPence"),
							rs.getString("BrewColour"),
							rs.getInt("Caffeine")
					);
				}
			}
			else {
				p = new Product(
						rs.getInt("Id"),
						rs.getString("Name"),
						rs.getString("Supplier"),
						rs.getInt("PriceInPence"),
						rs.getInt("Caffeine"),
						rs.getDouble("Recommend")
				);
			}
			
			if (isBasket) {
				p.setQuantity(rs.getInt("Quantity"));
			}
			
			products.add(p);		
		}
		return products;
	}
}
