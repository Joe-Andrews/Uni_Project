package util;

public enum ProductType {
	tea,
	coffee
}
