DROP DATABASE IF EXISTS totalitea;
CREATE DATABASE totalitea;
USE totalitea;


CREATE TABLE Product (
	Id INT PRIMARY KEY AUTO_INCREMENT,
	Name VARCHAR(50) NOT NULL,
    Type VARCHAR(10) NOT NULL,
    PriceInPence INT NOT NULL,
    IsSold BOOLEAN DEFAULT TRUE,
    Supplier VARCHAR (20),
    Caffeine INT NOT NULL,
    MedicinalUse TEXT,
    BrewColour VARCHAR(20),
    Recommend DOUBLE,
	CONSTRAINT ck_posPrice CHECK (PriceInPence > 0)
);


DELIMITER $$
CREATE PROCEDURE insertProduct(
	IN name VARCHAR(50),
    IN type VARCHAR(50),
	IN supplier VARCHAR(50),
	IN price INT,
    IN medicinalUse TEXT,
    IN caffeine INT,
    IN brewColour VARCHAR(20),
    IN recommend DOUBLE
)
BEGIN
	INSERT INTO Product (Name, Type, PriceInPence, Supplier, Caffeine, MedicinalUse, BrewColour, Recommend) 
	    VALUES (name, type, price, supplier, caffeine, medicinalUse, brewColour, recommend);
END;
$$

CREATE PROCEDURE readProducts()
BEGIN
	SELECT * FROM Product;
END;
$$

CREATE PROCEDURE showByType(
	IN category VARCHAR(10)
)
BEGIN
	SELECT * FROM Product WHERE Type LIKE category;
END
$$

CREATE PROCEDURE searchNameProduct(
	IN search TEXT
)
BEGIN
	SELECT * FROM Product WHERE Name LIKE CONCAT('%', search, '%');
END;
$$