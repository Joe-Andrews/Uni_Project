CREATE TABLE Basket (
	UserId INT,
	ProductId INT,
	Quantity INT NOT NULL,
	PRIMARY KEY (UserId, ProductId),
	CONSTRAINT fk_userId FOREIGN KEY (UserId) REFERENCES USERS(Id),
	CONSTRAINT fk_productId FOREIGN KEY (ProductId) REFERENCES Product(Id),
	CONSTRAINT ck_quantity CHECK (Quantity >= 0)
);

CREATE TABLE OrderItem (
	OId INT,
    PId INT,
    PRIMARY KEY (OId, PId)
);

CREATE TABLE OrderHistory (
	OId INT PRIMARY KEY,
    Userid INT NOT NULL,
    CONSTRAINT fk_OId FOREIGN KEY (OId) REFERENCES OrderItem(OId),
    CONSTRAINT fk_UId FOREIGN KEY (Userid) REFERENCES USERS(Id)
);


DELIMITER /
CREATE PROCEDURE insertItemIntoBasket(
	IN uid INT,
	IN pid INT,
	IN qty INT,
	OUT keyval INT
)
MODIFIES SQL DATA
BEGIN
	INSERT INTO Basket 
	    VALUES (uid, pid, qty);
	SELECT last_insert_id() INTO keyval;
	COMMIT;	
END;
/

CREATE PROCEDURE updateHistory (
	IN bid INT,
    IN uid INT,
    
    OUT keyval INT
)
MODIFIES SQL DATA
BEGIN
	INSERT INTO OrderHistory (BId, Userid) 
	    VALUES (bid, uid);
	SELECT last_insert_id() INTO keyval;
	COMMIT;	
END;
/

CREATE PROCEDURE placeOrder (
	IN oid INT,
    IN pid INT

)
MODIFIES SQL DATA
BEGIN
	INSERT INTO OrderItem (PId, OId) 
	    VALUES (pid, oid);
	COMMIT;	
END;
/

CREATE PROCEDURE updateExistingBasketItem(
	IN bid INT,
	IN pid INT,
	IN QuantityChange INT
)
MODIFIES SQL DATA
BEGIN
	UPDATE Basket SET
		Quantity = Quantity + QuantityChange
	WHERE BId = bid AND ProductId = pid;
END;
/

CREATE PROCEDURE removeBasketItem(
	IN id INT
)
BEGIN
	DELETE FROM Basket WHERE Id = idToDelete;
END;
/

CREATE PROCEDURE getBasketItems(
	IN inUserId INT
)
BEGIN
	SELECT p.*, Quantity
	FROM Basket b
	INNER JOIN Product p ON p.Id = ProductId
	WHERE UserId = inUserId;
END;
/

DELIMITER ;