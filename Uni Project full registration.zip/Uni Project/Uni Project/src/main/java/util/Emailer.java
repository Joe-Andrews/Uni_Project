package util;


import java.util.ArrayList;

import javax.mail.*;
import javax.mail.internet.*;




public class Emailer
{
	
	public static void main(String[]args)
	{
		sendEmail();
	}
	
	private ArrayList<String> createEmail()
	{
		//ArrayList is used to store the message and information for the email
		ArrayList<String> email = new ArrayList<String>();
		
		// Construct the message

		
		return email;
	}
	
	public static void sendEmail()
	{
		// Set up the SMTP server.
		java.util.Properties props = new java.util.Properties();
		props.put("mail.smtp.host", "smtp.myisp.com");
		Session session = Session.getDefaultInstance(props, null);
		
		String from = "receipt@totalitea.com";
		String to = "jake.m.roberts@outlook.com";
		String subject = "Receipt - NO RESPONSE";

		
		Message msg = new MimeMessage(session);
		try {
		    msg.setFrom(new InternetAddress(from));
		    msg.setRecipient(Message.RecipientType.TO, new InternetAddress(to));
		    msg.setSubject(subject);
		    msg.setText("Hi,\n\nHow are you?");

		    // Send the message.
		    Transport.send(msg);
		    
		} catch (MessagingException e) {
		    System.out.println("Failed to send email");
		}
	}
	
}
