package util;

import java.sql.ResultSet;
import java.sql.CallableStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.*;

public class ProductHandler {
	
	public static List<Product> getProductsBySearch(String search, List<Product> products) throws SQLException {

		if (search.length() == 0) {
			return products;
		}
		List<Product> returnList = new ArrayList<>();
		
		for (Product p : products) {
			if (p.getName().toLowerCase().contains(search)) {
				returnList.add(p);
			}
		}
		
		return returnList;
	}
	
	public static List<Product> getTea() throws SQLException {
		
		CallableStatement cs = DbConnector.getConnection().prepareCall("{CALL showByType(?)}");
		cs.setString(1, "tea");
		ResultSet rs = cs.executeQuery();
		
		return resultSetToProducts(rs);
		
	}
	
	public static List<Product> getCoffee() throws SQLException {
		
		CallableStatement cs = DbConnector.getConnection().prepareCall("{CALL showByType(?)}");
		cs.setString(1, "coffee");
		ResultSet rs = cs.executeQuery();
		
		return resultSetToProducts(rs);
	}
	
	public static List<Product> getDessert() throws SQLException {
		
		return resultSetToProducts(DbConnector.runSqlCallable("{CALL readDessert()}"));
		
	}
	
	public static List<Product> getProducts() throws SQLException {

		List<Product> products = getTea();
		
		products.addAll(getCoffee());
		products.addAll(getDessert());
		
		return products;
		
	}
	
	public static List<Product> resultSetToProducts(ResultSet rs) throws SQLException {
		return resultSetToProducts(rs, false);
	}
	
	public static List<Product> resultSetToProducts(ResultSet rs, boolean isBasket) throws SQLException{
		List<Product> products = new ArrayList<>();
		
		Product p;
		
		while(rs.next()){
			
			if (rs.getString("Type").equals("tea")) {
				if (rs.getInt("Caffeine") == 0) {
					
					p = new Product(
							rs.getInt("Id"),
							rs.getString("Name"),
							rs.getString("Supplier"),
							rs.getInt("PriceInPence"),
							rs.getString("BrewColour"),
							rs.getString("MedicinalUse")
					);
				}
				else {
					p = new Product(
							rs.getInt("Id"),
							rs.getString("Name"),
							rs.getString("Supplier"),
							rs.getInt("PriceInPence"),
							rs.getString("BrewColour"),
							rs.getInt("Caffeine")
					);
				}
			}
			else if (rs.getString("Type").equals("coffee")) {
				p = new Product(
						rs.getInt("Id"),
						rs.getString("Name"),
						rs.getString("Supplier"),
						rs.getInt("PriceInPence"),
						rs.getInt("Caffeine"),
						rs.getDouble("Recommend")
				);
			}
			else {
				p = new Product(
						rs.getInt("Id"),
						rs.getString("Name"),
						rs.getString("Supplier"),
						rs.getInt("PriceInPence"),
						rs.getBoolean("HasNuts"),
						rs.getBoolean("HasDairy"),
						rs.getInt("Sugar"),
						rs.getInt("SFat")
				);
						
			}
			
			if (isBasket) {
				p.setQuantity(rs.getInt("Quantity"));
			}
			
			products.add(p);		
		}
		return products;
	}
}
