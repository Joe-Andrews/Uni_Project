/**
 * 
 */
package util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import model.Product;

/**
 * @author owens
 *
 */
public class BasketHandler {
	
	public static boolean addToBasket(int pid, int qty, int uid) throws SQLException{
		
		CallableStatement cs;
		
		if (checkBasket(pid, uid)) {
			cs = DbConnector.getConnection().prepareCall("{call updateExistingBasketItem(?,?,?)}");
		}
		else {
			cs = DbConnector.getConnection().prepareCall("{call insertItemIntoBasket(?,?,?)}");
		}
		
		cs.setInt(1, uid);
		cs.setInt(2, pid);
		cs.setInt(3,  qty);
		cs.execute();
		
		return true;
		
	}
	
	public static void clearBasket(int uid) {
		
		try {
			CallableStatement cs = DbConnector.getConnection().prepareCall("CALL clearBasket(?)");
			cs.setInt(1, uid);
			
			cs.execute();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static int getBasketWeight(int uid) {
		
		try {
			CallableStatement cs = DbConnector.getConnection().prepareCall("{CALL basketWeight(?)}");
			cs.setInt(1, uid);
			
			ResultSet rs = cs.executeQuery();
			
			if (!rs.next()) {
				return 0;
			}
			
			return rs.getInt(1);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return -1;
		
	}
	
	public static int getShippingCost(int uid) {
		
		int weight = getBasketWeight(uid);
		
		if (weight < 5000) {
			return 1;
		}
		if (weight < 10000) {
			return 10;
		}
		return 15;
		
	}
	
	public static String getBasketSum(int uid) {
		
		CallableStatement cs;
		
		try {
			cs = DbConnector.getConnection().prepareCall("{CALL basketSum(?)}");
			cs.setInt(1, uid);
			
			ResultSet rs = cs.executeQuery();
			
			rs.next();
			
			BigDecimal bd = new BigDecimal(rs.getInt(1) / 100.0);
		    bd = bd.setScale(2, RoundingMode.HALF_UP);
		    
		    return "£" + bd.toString();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "ERROR";
		}
		
	}
	
	public static boolean checkBasket(int pid, int uid) {
		
		try {
			CallableStatement cs = DbConnector.getConnection().prepareCall("{CALL checkBasketForItem(?,?)}");
			cs.setInt(1, uid);
			cs.setInt(2, pid);
			
			ResultSet rs = cs.executeQuery();
			
			rs.next();
			
			if (rs.getInt(1) != 0) {
				return true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
	
	public static List<Product> getItemsFromBasket(int uid) throws SQLException {

		CallableStatement cs = DbConnector.getConnection().prepareCall("{CALL getBasketItems(?)}");
		
		cs.setInt(1, uid);
		ResultSet rs = cs.executeQuery();
		
		return ProductHandler.resultSetToProducts(rs, true);
		
	}
	
	public static void removeItemFromBasket(int pid, int qty, int uid) throws SQLException {
		
		CallableStatement cs = DbConnector.getConnection().prepareCall("{CALL removeBasketItem(?,?,?)}");
		
		cs.setInt(1, uid);
		cs.setInt(2, pid);
		cs.setInt(3, qty);
		
		cs.execute();
		
	}

}
