package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import model.Product;
import util.ProductHandler;

/**
 * Servlet implementation class ProductList
 */
@WebServlet("/ProductList")
public class ProductList extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public ProductList() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Generate list of products; hand over to a JSP page to display them.
		// We can get any parameters we need from the request (we don't need/use any at the moment).
		List<Product> products = new ArrayList<Product>();
		
		try {
			String searchQuery = request.getParameter("search");
			
			if (searchQuery == null) {
				searchQuery = "";
			}
			searchQuery = searchQuery.strip();
			
			request.setAttribute("searchQuery", searchQuery);
			
			if (request.getParameter("Dessert") != null) {
				products.addAll(ProductHandler.getDessert());
				request.setAttribute("Dessert", true);
			}
			else {
				request.setAttribute("Dessert", false);
			}
			if (request.getParameter("Tea") != null) {
				products.addAll(ProductHandler.getTea());
				request.setAttribute("Tea", true);
			}
			else {
				request.setAttribute("Tea", false);
			}
			
			if (request.getParameter("Coffee") != null) {
				products.addAll(ProductHandler.getCoffee());
				request.setAttribute("Coffee", true);
			}
			else {
				request.setAttribute("Coffee", false);
			}
			
			if (products.size() == 0) {
				products = ProductHandler.getProducts();
			}
			
			products = ProductHandler.getProductsBySearch(searchQuery, products);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		// Rather than embed lots of HTML into servlets; place the data you wan tto handle into the request
		request.setAttribute("products", products);
		// ... then forward the request to a JSP 'hidden' inside WEB_INF (so, can't be accessed directly by the user)
		RequestDispatcher rd = request.getRequestDispatcher("ProductPage.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// If called via POST... do what we'd do if called via GET.
		doGet(request, response);
	}

}
