CREATE TABLE USERS (
	Id INT PRIMARY KEY AUTO_INCREMENT,
	Email VARCHAR(50) UNIQUE NOT NULL,
    Password VARCHAR(20) NOT NULL,
    AccountType BOOLEAN DEFAULT FALSE,
    DOB DATE,
    FName VARCHAR(20),
    LName VARCHAR(20)
);


CREATE TABLE Address(
	UserID INT,
    FirstLine VARCHAR(50) NOT NULL,
    SecondLine VARCHAR(50),
    City VARCHAR(20) NOT NULL,
    County VARCHAR(20),
    Postcode VARCHAR(10) NOT NULL,
    CONSTRAINT fk_uidAddress FOREIGN KEY (UserID) REFERENCES USERS(Id)
);

DELIMITER /

CREATE PROCEDURE newUser (
	IN email  VARCHAR(50),
    IN password  VARCHAR(20),
    IN dob DATE,
    IN fname VARCHAR(20),
    IN lname VARCHAR(20),
    OUT newId INT
)
BEGIN

	DECLARE dup_val_on_index_error CONDITION FOR 1062;
	DECLARE CONTINUE HANDLER FOR dup_val_on_index_error
	BEGIN
		SET @msg = CONCAT('Email ', email, ' is already recorded.');
		RESIGNAL SET MESSAGE_TEXT = @msg;
	END;
    
	INSERT INTO USERS (Email, Password, DOB, FName, LName) 
	    VALUES (email, password, dob, fname, lname);
	SET newId = LAST_INSERT_ID();
END;
/

CREATE PROCEDURE newAdmin (
	IN email VARCHAR(50),
    IN password VARCHAR(20),
    IN dob DATE,
    IN fname VARCHAR(20),
    IN lname VARCHAR(20),
    OUT newId INT
)
BEGIN

	DECLARE dup_val_on_index_error CONDITION FOR 1062;
	DECLARE CONTINUE HANDLER FOR dup_val_on_index_error
	BEGIN
		SET @msg = CONCAT('Email ', email, ' is already recorded.');
		RESIGNAL SET MESSAGE_TEXT = @msg;
	END;
    
	INSERT INTO USERS (Email, Password, DOB, FName, LName, AccountType) 
	    VALUES (email, password, dob, fname, lname, TRUE);
	SET newId = LAST_INSERT_ID();
END;
/

CREATE PROCEDURE setAddress(
	IN uid INT,
    IN address1 VARCHAR(50),
    IN address2 VARCHAR(50),
    IN city VARCHAR(20),
    IN county VARCHAR(20),
    IN postcode VARCHAR(10)
)
BEGIN
    INSERT INTO Address VALUES
		(uid, address1, address2, city, county, postcode);
END;
/

CREATE PROCEDURE getAddress(
	IN uid INT
)
BEGIN
	SELECT *
	FROM Address
	WHERE UserId = uid;
END 

CREATE PROCEDURE deleteUser (
	IN idToDelete INT
)
BEGIN
	DELETE FROM USERS WHERE Id = idToDelete;
END;
/

CREATE PROCEDURE loginCheck(
	IN mail VARCHAR(20),
    IN pass VARCHAR(20)
    )
BEGIN
	SELECT Id FROM USERS WHERE Email = mail AND Password = pass;
END;
/

CREATE PROCEDURE getUserInfo (
	IN uid INT
)
BEGIN
	SELECT FName, LName, Email
    FROM Users
    WHERE Id = uid;
END;
/

DELIMITER ;

SET @genid = -1;

CALL newAdmin ('admin@admin', 'admin', '1999-11-17', 'john', 'doe', @genid);



