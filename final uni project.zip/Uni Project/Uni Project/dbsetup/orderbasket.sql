CREATE TABLE Basket (
	UserId INT,
	ProductId INT,
	Quantity INT NOT NULL,
	PRIMARY KEY (UserId, ProductId),
	CONSTRAINT fk_userId FOREIGN KEY (UserId) REFERENCES USERS(Id),
	CONSTRAINT fk_productId FOREIGN KEY (ProductId) REFERENCES Product(Id),
	CONSTRAINT ck_quantity CHECK (Quantity >= 0)
);

CREATE TABLE OrderItem (
	OId INT,
    PId INT,
    PRIMARY KEY (OId, PId)
);

CREATE TABLE OrderHistory (
	OId INT PRIMARY KEY,
    Userid INT NOT NULL,
    CONSTRAINT fk_OId FOREIGN KEY (OId) REFERENCES OrderItem(OId),
    CONSTRAINT fk_UIdOrderHistory FOREIGN KEY (Userid) REFERENCES USERS(Id)
);

DELIMITER /

CREATE PROCEDURE insertItemIntoBasket(
	IN uid INT,
	IN pid INT,
	IN qty INT
)
MODIFIES SQL DATA
BEGIN
	INSERT INTO Basket 
	    VALUES (uid, pid, qty);
	COMMIT;	
END;
/

CREATE PROCEDURE clearBasket(
	IN uid INT
)
BEGIN
	DELETE FROM Basket
	WHERE UserId = uid;
END;
/

CREATE PROCEDURE updateHistory (
	IN bid INT,
    IN uid INT,
    
    OUT keyval INT
)
MODIFIES SQL DATA
BEGIN
	INSERT INTO OrderHistory (BId, Userid) 
	    VALUES (bid, uid);
	SELECT last_insert_id() INTO keyval;
	COMMIT;	
END;
/

CREATE PROCEDURE placeOrder (
	IN oid INT,
    IN pid INT

)
MODIFIES SQL DATA
BEGIN
	INSERT INTO OrderItem (PId, OId) 
	    VALUES (pid, oid);
	COMMIT;	
END;
/

CREATE PROCEDURE checkBasketForItem (
	IN uid INT,
    IN pid INT
)
BEGIN
	SELECT COUNT(*)
    FROM Basket
    WHERE ProductId = pid AND UserId = uid;
END;
/

CREATE PROCEDURE basketSum (
	IN uid INT
)
BEGIN
	SELECT SUM(p.PriceInPence * Quantity)
    FROM Basket
    INNER JOIN Product p ON p.Id = ProductId
    WHERE UserId = uid;
END;
/

CREATE PROCEDURE basketWeight (
	IN uid INT
)
BEGIN 
	SELECT SUM(p.Weight * Quantity)
    FROM Basket
    INNER JOIN Product p ON p.Id = ProductId
    WHERE UserId = uid;
END;
/

CREATE PROCEDURE updateExistingBasketItem(
	IN uid INT,
	IN pid INT,
	IN QuantityChange INT
)
MODIFIES SQL DATA
BEGIN
	UPDATE Basket SET
		Quantity = Quantity + QuantityChange
	WHERE UserId = uid AND ProductId = pid;
END;
/

CREATE PROCEDURE removeBasketItem(
	IN uid INT,
    IN pid INT,
    IN qty INT
)
BEGIN
    IF EXISTS(
		SELECT *
        FROM Basket
        WHERE UserId = uid AND ProductId = pid AND Quantity <= qty
    ) THEN
		DELETE FROM Basket
        WHERE UserId = uid AND ProductId = pid;
	ELSE

		UPDATE Basket SET
		Quantity = Quantity - qty
        WHERE UserId = uid AND ProductId = pid;
	END IF;
END;
/

CREATE PROCEDURE getBasketItems(
	IN inUserId INT
)
BEGIN
	SELECT p.*, tc.Caffeine, tc.MedicinalUse, tc.BrewColour, tc.Recommend, d.HasNuts, d.HasDairy, d.Sugar, d.SFat, Quantity
	FROM Basket b
	LEFT JOIN Product p ON p.Id = ProductId
    LEFT JOIN TeaCoffee tc ON tc.Id = p.Id
    LEFT JOIN Dessert d ON d.Id = tc.Id
	WHERE UserId = inUserId
    ORDER BY p.Type DESC;
END;
/
DELIMITER ;