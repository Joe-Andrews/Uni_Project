package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import util.UserHandler;

class UserHandlerTest {

	@Test
	void createTest() {
		
		//UserHandler.createAccount("test@user", "pass", false);
		
		//assertFalse(UserHandler.createAccount("test@user", "pass", false));
		
	}
	
	@Test
	void signInTest() {
		
		assertEquals(-1, UserHandler.signIn("hj37Shkf;=30", "1234567890"));
		
		//UserHandler.createAccount("test@user", "pass", false);
		
		assertTrue(UserHandler.signIn("test@user", "pass") > 0);
	}

}
