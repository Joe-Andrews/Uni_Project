package test;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;
import java.util.List;

import org.junit.jupiter.api.Test;

import model.Product;
import util.ProductHandler;
import util.ProductType;

class ProductHandlerTest {

	@Test
	void getProductsTest() throws SQLException {
		List<Product> products = ProductHandler.getProducts();
		assertEquals(15, products.size());
		
	}
	
	@Test
	void getTeaTest() throws SQLException {
		List<Product> products = ProductHandler.getTea();
		
		for (Product p : products) {
			assertEquals(ProductType.tea, p.getType());
		}
	}
	
	@Test
	void getCoffeeTest() throws SQLException {
		List<Product> products = ProductHandler.getCoffee();
		
		for (Product p : products) {
			assertEquals(ProductType.coffee, p.getType());
		}
	}
	
	@Test
	void getProductsBySearchTest() throws SQLException {
		
		/*List<Product> products = ProductHandler.getProductsBySearch("ree");
		
		for (Product p : products) {
			assertEquals(ProductType.tea, p.getType());
			assertTrue(p.getName().equals("Green Tea"));
		}*/
		
	}
	 /**
	  * dependent on searchTest passing
	  * checks product object against dummy data
	  */
	@Test
	void rsToProductTest() throws SQLException {
		List<Product> products = ProductHandler.getProductsBySearch("Excelsa", ProductHandler.getProducts());
		
		Product p = products.get(0);
		
		assertEquals(15, p.getId());
		assertTrue(p.getName().equals("Excelsa"));
		assertEquals(ProductType.coffee, p.getType());
		assertEquals(250, p.getPrice());
		assertTrue(p.getSupplier().equals("Espreszo"));
		assertEquals(12, p.getCaffeineContent());
		assertNull(p.getMedicinalUse());
		assertNull(p.getBrewColour());
		assertEquals(4, p.getRecAmt());
	}

}
