package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import util.UserHandler;
 

@WebServlet("/Registration")
public class Registration extends HttpServlet {
 
    private static final long serialVersionUID = 1L;
 
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
        throws ServletException, IOException
    {
    	String FName = request.getParameter("firstName");
    	String LName = request.getParameter("lastName");
    	String dob = request.getParameter("dob");
        String email = request.getParameter("email").toLowerCase();
        String password = request.getParameter("password");
        String confirmedPassword = request.getParameter("confirmpassword");
        
        String address1 = request.getParameter("address1");
    	String address2 = request.getParameter("address2");
    	String city = request.getParameter("city");
    	String county = request.getParameter("county");
    	String postcode = request.getParameter("postcode");
        
        
        String[] dateList = dob.split("-");
        
        for (String s : dateList) {
        	if (s.length() == 0) {
        		response.sendRedirect("Registration.jsp");
        		return;
        	}
        }
        
		Date dobDate = new Date(Integer.parseInt(dateList[0]), Integer.parseInt(dateList[1]), Integer.parseInt(dateList[2]));
		
		int genid = UserHandler.createAccount(email, password, dobDate, FName, LName, false);
		
		System.out.println(genid);

    	if(genid > 0 && password.equals(confirmedPassword)) {
    		
    		if ((address1 + city + postcode).length() != 0) {
    			UserHandler.setAddress(genid, address1, address2, city, county, postcode);
    			response.sendRedirect("LoginPage.jsp");
    			return;
    		}
    	}

    	UserHandler.removeAccount(genid);
    	response.sendRedirect("Registration.jsp");
    	
    }
 
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
        throws ServletException, IOException
    {
 
        doGet(request, response);
    }
}
