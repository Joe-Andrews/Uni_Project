package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import util.BasketHandler;
import util.PriceHandler;
import util.UserHandler;

import java.io.IOException;

/**
 * Servlet implementation class Checkout
 */
@WebServlet("/Checkout")
public class Checkout extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public Checkout() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		HttpSession session = request.getSession();
		int uid = session.getAttribute("ID");
		
		if (BasketHandler.getItemsFromBasket(uid).size() != 0) {
			
			int shippingCost;
			int basketPriceInPence = BasketHandler.getBasketSum(uid);
			
			if (basketPriceInPence > 10000) {
				shippingCost = 0;
			}
			else {
				shippingCost = BasketHandler.getShippingCost(uid);
			}
			
			request.setAttribute("address", UserHandler.getAddress(uid));
			request.setAttribute("basketPrice", PriceHandler.getPriceString(basketPriceInPence));
			request.setAttribute("shippingPrice", shippingCost);
			request.getAttribute("total", PriceHandler.getPriceString(basketPriceInPence + (shippingCost * 100)));
		
			RequestDispatcher rd = request.getRequestDispatcher("projectCheckout.jsp");
			rd.forward(request, response);
			return;
			
		}
		
		response.sendRedirect("ProductList");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
