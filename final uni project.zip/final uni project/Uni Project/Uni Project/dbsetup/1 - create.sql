DROP DATABASE IF EXISTS totaliteadb;
CREATE DATABASE totaliteadb;
USE totaliteadb;

CREATE USER 'totaliteauser'@'localhost' IDENTIFIED BY 'testpass';
GRANT EXECUTE ON totaliteadb.* TO 'totaliteauser'@'localhost';

CREATE TABLE Product (
	Id INT PRIMARY KEY AUTO_INCREMENT,
	Name VARCHAR(50) NOT NULL,
    Type VARCHAR(10) NOT NULL,
	Supplier VARCHAR (20),
    PriceInPence INT NOT NULL,
    Weight INT NOT NULL,
	IsSold BOOLEAN DEFAULT TRUE,
    CONSTRAINT priceNotNeg CHECK (PriceInPence >= 0)
);

CREATE TABLE Dessert(
	Id INT NOT NULL PRIMARY KEY,
	HasNuts BOOLEAN NOT NULL,
    HasDairy BOOLEAN NOT NULL,
    Sugar INT NOT NULL,
    SFat INT NOT NULL,
    CONSTRAINT fk_Did FOREIGN KEY (Id) REFERENCES Product(Id)
);

CREATE TABLE TeaCoffee(
	Id INT NOT NULL PRIMARY KEY,
    Caffeine INT NOT NULL,
    MedicinalUse TEXT,
    BrewColour VARCHAR(20),
    Recommend DOUBLE,
    CONSTRAINT fk_tcid FOREIGN KEY (Id) REFERENCES Product(Id)
);

DELIMITER $$
CREATE PROCEDURE insertTCProduct(
	IN name VARCHAR(50),
    IN type VARCHAR(50),
	IN supplier VARCHAR(50),
	IN price INT,
    IN weight INT,
    IN medicinalUse TEXT,
    IN caffeine INT,
    IN brewColour VARCHAR(20),
    IN recommend DOUBLE
)
BEGIN
	INSERT INTO Product (Name, Type, Supplier, PriceInPence, Weight) 
	    VALUES (name, type, supplier, price, weight);
	INSERT INTO TeaCoffee(Id, Caffeine, MedicinalUse, BrewColour, Recommend)
		VALUES (last_insert_id(), caffeine, medicinalUse, brewColour, recommend);
END;
$$

CREATE PROCEDURE insertDessert(
	IN name VARCHAR(50),
    IN type VARCHAR(50),
	IN supplier VARCHAR(50),
    IN price INT,
    IN weight INT,
    IN hasNuts BOOLEAN,
    IN hasDairy BOOLEAN,
    IN sugar INT,
    IN sfat INT
)
BEGIN
	INSERT INTO Product (Name, Type, Supplier, PriceInPence, Weight) 
	    VALUES (name, type, supplier, price, weight);
	INSERT INTO Dessert(Id, HasNuts, HasDairy, Sugar, SFat)
		VALUES (last_insert_id(), hasNuts, hasDairy, sugar, sfat);
END;
$$

CREATE PROCEDURE readTeaCoffee()
BEGIN
	SELECT * FROM Product 
    INNER JOIN TeaCoffee
    ON Product.Id = TeaCoffee.Id
    WHERE IsSold = TRUE;
END;
$$

CREATE PROCEDURE readDessert()
BEGIN
	SELECT * FROM Product 
    INNER JOIN Dessert
    ON Product.Id = Dessert.Id
    WHERE IsSold = TRUE;
END;
$$

CREATE PROCEDURE showByType(
	IN category VARCHAR(10)
)
BEGIN
	SELECT * FROM Product 
	INNER JOIN TeaCoffee
	ON Product.Id = TeaCoffee.Id
	WHERE Type LIKE category AND IsSold = TRUE;
END;
$$

CREATE PROCEDURE searchNameProduct(
	IN search TEXT
)
BEGIN
	SELECT * FROM Product 
    INNER JOIN TeaCoffee
	ON Product.Id = TeaCoffee.Id
    INNER JOIN Dessert
    ON Product.Id = Dessert.Id
    WHERE Name LIKE CONCAT('%', search, '%') AND IsSold = TRUE;
END;
$$