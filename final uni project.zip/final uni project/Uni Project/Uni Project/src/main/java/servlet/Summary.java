package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import util.BasketHandler;

import java.io.IOException;

/**
 * Servlet implementation class Summary
 */
public class Summary extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Summary() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		HttpSession session = request.getSession();
		int uid = (int) session.getAttribute("ID");
		
		if (((String) request.getParameter("cardNumber")) == null) {
			response.sendRedirect("Checkout");
			return;
		}
		if (((String) request.getParameter("cardName")) == null) {
			response.sendRedirect("Checkout");
			return;
		}
		if (((String) request.getParameter("expiryDate")) == null) {
			response.sendRedirect("Checkout");
			return;
		}
		if (((String) request.getParameter("cvc")) == null) {
			response.sendRedirect("Checkout");
			return;
		}
		
		BasketHandler.clearBasket(uid);
		
		response.sendRedirect("SummaryPage.jsp");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
