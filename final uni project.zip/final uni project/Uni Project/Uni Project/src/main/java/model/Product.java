package model;

/**
 * CHANGES:
 * added quantity to product for easier use with basket
 * fixed included product page
 * wrote tests for userhandler and producthandler
 * slightly changed productHandler to use quantity
 * rewrote basketHandler and got the given sql for the basket working
 * got the addToBasket servlet working
 * 
 * 
 * 
 * TO DO:
 * decide whether or not we are using the navbar given to us that the product page currently uses
 * put search bar and checkboxes and such on product page
 * make basket page
 * write method for getting items from db in a certain price range. needs sql procedure too
 * 
 * would be nice to call all create sql commands automatically when open website. maybe only do it when a new user signs in for better efficiency
 */

import java.math.BigDecimal;
import java.math.RoundingMode;

import util.ProductType;

public class Product {
	private int id, price, caffeineContent, quantity, sugar, SFat, weight; // id=0 means no id set (a new, unsaved, product)
	private String name, supplier, brewColour, medicinalUse;
	private ProductType type;
	private double recAmt;
	private boolean hasNuts, hasDairy;
	
	public Product(int id, String name, String supplier, int price, int weight, boolean hasNuts, boolean hasDairy, int sugar, int SFat) {
		this(id, name, supplier, price, weight);
		this.hasDairy = hasDairy;
		this.hasNuts = hasNuts;
		this.sugar = sugar;
		this.SFat = SFat;
		this.type = ProductType.dessert;
	}
	
	public Product(int id, String name, String supplier, int price, int weight, String brewColour, int caffeineContent) {
		this(id, name, supplier, price, weight);
		this.brewColour=  brewColour;
		this.caffeineContent = caffeineContent;
		this.type = ProductType.tea;
	}
	
	public Product(int id, String name, String supplier, int price, int weight, String brewColour, String medicinalUse) {
		this(id, name, supplier, price, weight);
		this.medicinalUse = medicinalUse;
		this.brewColour = brewColour;
		this.caffeineContent = caffeineContent;
		this.type = ProductType.tea;
	}
	
	public Product(int id, String name, String supplier, int price, int weight, int caffeineContent, double recAmt) {
		this(id, name, supplier, price, weight);
		this.recAmt = recAmt;
		this.caffeineContent = caffeineContent;
		this.type = ProductType.coffee;
	}
	
	private Product(int id, String name, String supplier, int price, int weight) {
		this.id = id;
		this.name = name;
		this.supplier = supplier;
		this.price = price;
		this.weight = weight;
		hasDairy = false;
		hasNuts = false;

	}
	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public int getWeight() {
		return weight;
	}
	
	/**
	 * @return quantity of item when it is in the basket
	 */
	public int getQuantity() {
		return quantity;
	}
	
	/**
	 * @return amount of sugar in milligrams
	 */
	public int getSugar() {
		return sugar;
	}

	/**
	 * @return amount of saturated fat in milligrams
	 */
	public int getSFat() {
		return SFat;
	}
	
	/**
	 * @return true if the dessert contains dairy
	 */
	public boolean hasDairy() {
		return hasDairy;
	}
	
	/**
	 * @return true if the dessert contains nuts
	 */
	public boolean hasNuts() {
		return hasNuts;
	}
	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return the description
	 */
	public String getSupplier() {
		return supplier;
	}

	/**
	 * @return the price
	 */
	public int getPrice() {
		return price;
	}

	/**
	 * @return if this item is tea or coffee
	 */
	public ProductType getType() {
		return type;
	}

	/**
	 * @return the amount of caffeine in the tea in grams
	 */
	public int getCaffeineContent() {
		return caffeineContent;
	}
	
	/**
	 * @return the colour of the tea brew
	 */
	public String getBrewColour() {
		return brewColour;
	}

	/**
	 * @return the medicinal use of a herbal tea
	 */
	public String getMedicinalUse() {
		return medicinalUse;
	}

	/**
	 * @return the recommended amount for coffee
	 */
	public double getRecAmt() {
		return recAmt;
	}

	/**
	 * @return price formatted with two decimal places to represent pounds & pence (or dollars & cents, or...)
	 */
	public String getPriceString(){
		BigDecimal bd = new BigDecimal(price / 100.0);
	    bd = bd.setScale(2, RoundingMode.HALF_UP);
	    
	    return "£" + bd.toString();
	}
	
	/**
	 * base description of any item
	 */
	public String toString(){
		String desc;
		if (type == ProductType.tea) {
			desc = "A";
			if ("AEIOUaeiou".indexOf(brewColour.charAt(0)) != -1) {
				desc += "n";
			}
			
			desc += " " + brewColour + " tea";

			if (medicinalUse != null) {
				desc += " mainly used for " + medicinalUse;
			}
			else {
				desc += " with " + caffeineContent + " milligrams of caffeine per gram of tea.";
			}
		}
		else if (type == ProductType.coffee) {
			desc = "A coffee with " + caffeineContent + " milligrams of caffeine per gram of coffee.\n";
			desc += "Reccommended amount per drink is " + recAmt + " grams.";
		}
		else {
			desc = "A";
			if (!hasDairy) {
				desc += " dairy free";
			}
			desc += " dessert";
			if (!hasNuts) {
				desc += " with no nuts";
			}
			desc += ". Contains " + sugar + " mg of sugar and " + SFat + " mg of saturated fat.";
		}
		
		desc += " (" + weight + " g)";
		
		return desc;
	}

}