package util;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class UserHandler {

	public static Integer signIn(String user, String password) {
		
		try {
			CallableStatement cs = DbConnector.getConnection().prepareCall("{call loginCheck(?,?)}");
			cs.setString(1, user);
			cs.setString(2, password);
			ResultSet rs = cs.executeQuery();
			
			if (rs.next()) {
				return rs.getInt(1);
			}
			
		} catch (SQLException sqle) {
			System.out.println(sqle);
		}
		
		return -1;
	}
	
	public static int createAccount(String user, String password, Date dob, String FName, String LName, boolean isAdmin) {
		try {
			Connection conn = DbConnector.getConnection();
			CallableStatement cs;
			
			//if sign in works, account already exists
			if (signIn(user, password) != -1) {
				return -2;
			}
			
			if (isAdmin) {
				cs = conn.prepareCall("{call newAdmin(?,?,?,?,?,?)}");
			}
			else {
				cs = conn.prepareCall("call newUser(?,?,?,?,?,?)");
			}
			
			cs.setString(1, user);
			cs.setString(2, password);
			cs.setDate(3, dob);
			cs.setString(4, FName);
			cs.setString(5, LName);
			cs.registerOutParameter(6, Types.INTEGER);
			cs.execute();
			
			return cs.getInt(6);
			
		} catch (SQLException sqle) {
			System.out.println(sqle);
		}
		
		return -3;
	}
	
	public static boolean setAddress(int uid, String address1, String address2, String city, String county, String postcode) {
		
		try {
			CallableStatement cs = DbConnector.getConnection().prepareCall("{CALL setAddress(?,?,?,?,?,?)}");
			cs.setInt(1, uid);
			cs.setString(2, address1);
			cs.setString(3, address2);
			cs.setString(4, city);
			cs.setString(5, county);
			cs.setString(6, postcode);
			
			cs.execute();
			
			return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
		
	}
	
	public static void removeAccount(int uid) {
		
		try {
			CallableStatement cs = DbConnector.getConnection().prepareCall("{CALL deleteUser(?)}");
			cs.setInt(1, uid);
			
			cs.execute();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static String getAddress(int uid) {
		
		CallableStatement cs;
		try {
			cs = DbConnector.getConnection().prepareCall("{CALL getAddress(?)}");
			cs.setInt(1, uid);
			
			ResultSet rs = cs.executeQuery();
			
			if (!rs.next()) {
				return "ADDRESS NOT FOUND";
			}
			
			String address = "";
			String addString = "";
			
			address += rs.getString("FirstLine") + ", ";

			addString = rs.getString("SecondLine");
			if (addString.strip().length() != 0) {
				address += addString + ", ";
			}
			
			address += rs.getString("Postcode") + ", ";
			address += rs.getString("City");
			addString = rs.getString("County");
			
			if (addString.strip().length() != 0) {
				address += ", " + addString;
			}
			
			return address;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return "ERROR";
		
	}
	
	public static List<String> getName(int uid) {
		
		List<String> info = new ArrayList<>();
		
		try {
			CallableStatement cs = DbConnector.getConnection().prepareCall("{CALL getUserInfo(?)}");
			cs.setInt(1, uid);
			
			ResultSet rs = cs.executeQuery();
			
			if (!rs.next()) {
				return null;
			}
			
			info.add(rs.getString("FName"));
			info.add(rs.getString("LName"));
			info.add(rs.getString("Email"));

			return info;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
		
	}
	
}
